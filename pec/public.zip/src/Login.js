import React, { useState } from 'react'
import './Login.css'

export default function Login() {

    const handleSubmit = (e) => {
        e.preventDefault();
    }

    return (
        <>
            <div className='login-form'>
                <center>
                    <h1>AI Educator</h1>
                </center>

                <form onSubmit={handleSubmit}>
                    <label htmlFor='email'>Email : </label>
                    <input type='email' id='email' name='email' required />

                    <label htmlFor='password'>Password : </label>
                    <input type='password' id='password' name='password' required />

                    <button type='submit'>Login</button>
                </form>
            </div>

        </>
    )
}
